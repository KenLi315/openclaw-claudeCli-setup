---
name: restore-setting-from-github
description: Restore OpenClaw config from GitHub backup. Use when user says "restore setting from Github" or "還原設定". Requires GITHUB_TOKEN and GITHUB_BACKUP_REPO.
metadata:
  openclaw:
    requires:
      env: ["GITHUB_TOKEN", "GITHUB_BACKUP_REPO"]
---

# Restore Setting from Github

從 GitHub 下載最新備份並還原 OpenClaw 設定。

## When to Use

用戶說「restore setting from Github」「還原設定」「reset setting」「從備份還原」時使用。

## Workflow

1. 執行 bash {baseDir}/scripts/restore-from-github.sh
2. 從輸出擷取 RESTORED_FROM=backup-YYYYMMDD_HHMMSS.tar.gz
3. 通知用戶：設定已還原、還原來源檔名、請在 Zeabur 執行 Redeploy 或 Restart
