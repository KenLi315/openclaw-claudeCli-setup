#!/bin/bash
set -e
REPO="${GITHUB_BACKUP_REPO:-}"
TOKEN="${GITHUB_TOKEN:-}"
OPENCLAW_ROOT="${OPENCLAW_STATE_DIR:-$HOME/.openclaw}"
BACKUP_DIR="/app/backup"
if [ -z "$TOKEN" ] || [ -z "$REPO" ]; then
  echo "[restore] GITHUB_TOKEN 或 GITHUB_BACKUP_REPO 未設定"
  exit 1
fi
mkdir -p "$BACKUP_DIR"
LATEST=$(curl -s -H "Authorization: token $TOKEN" "https://api.github.com/repos/$REPO/contents/backup" | grep -oE 'backup-[0-9]{8}_[0-9]{6}\.tar\.gz' | sort -r | head -1)
if [ -z "$LATEST" ]; then
  echo "[restore] 找不到備份檔"
  exit 1
fi
echo "[restore] 下載 $LATEST ..."
curl -sL -H "Authorization: token $TOKEN" -H "Accept: application/vnd.github.v3.raw" "https://api.github.com/repos/$REPO/contents/backup/$LATEST" | tar -xzv -C "$BACKUP_DIR"
[ -f "$BACKUP_DIR/openclaw.json" ] && cp "$BACKUP_DIR/openclaw.json" "$OPENCLAW_ROOT/openclaw.json" && echo "[restore] ✓ openclaw.json"
for ws_dir in "$BACKUP_DIR/workspaces"/*; do
  [ -d "$ws_dir" ] || continue
  ws_name=$(basename "$ws_dir")
  ws_dest="$OPENCLAW_ROOT/$ws_name"
  mkdir -p "$ws_dest" "$ws_dest/memory"
  for f in AGENTS.md SOUL.md MEMORY.md USER.md; do
    [ -f "$ws_dir/$f" ] && cp "$ws_dir/$f" "$ws_dest/$f" && echo "[restore] ✓ $ws_name/$f"
  done
  [ -d "$ws_dir/memory" ] && cp "$ws_dir"/memory/*.md "$ws_dest/memory/" 2>/dev/null
done
echo "[restore] 完成：$LATEST"
echo "RESTORED_FROM=$LATEST"
