---
name: memory-vault-manager
description: 自動化管理 Ken 的 GitHub 記憶庫與 Trello 任務儀表板。
metadata: {"clawdbot":{"emoji":"🧠","requires":{"bins":["python3"],"env":["TRELLO_API_KEY","TRELLO_TOKEN"]}}}
---

# Memory Vault Manager Skill

將會話總結、任務及知識提取自動化，並同步至 Trello 與 GitHub。

## 核心規則 (今日經驗整合 2026-03-08)

1.  **憑證永久化**：憑證必須存放在 `~/.openclaw/credentials/trello.json`，嚴禁僅依賴臨時環境變數。
2.  **日程命名規範**：日程類型的卡片，標題必須使用「事件發生日期」作為前綴（例如 `[03/15] 演唱會`），而非「建立日期」。
3.  **時間細粒度**：
    -   記錄日程時，必須包含開始與結束時間。
    -   應優先使用 Trello 的原生參數 (`start`, `due`) 進行紀錄，以便於日曆視圖呈現。
4.  **分類邏輯**：
    -   `summary`: 歸類至「會話總結 (Session Summaries)」欄位。
    -   `task`: 歸類至「任務 (Tasks)」欄位。
    -   `schedule`: 歸類至「日程 (Schedule)」欄位。

## 指令範例

### 1. 提交會話總結 (Session Summary)
```bash
python3 ~/.openclaw/skills/memory-vault-manager/bin/vault.py summary "標題" "內容描述"
```

### 2. 分派新任務 (New Task)
```bash
python3 ~/.openclaw/skills/memory-vault-manager/bin/vault.py task "任務標題" "任務內容描述"
```

### 3. 記錄正式日程 (New Schedule)
```bash
# 參數：模式 "標題" "內容" "事件日期(MM/DD)" "ISO開始時間"
python3 ~/.openclaw/skills/memory-vault-manager/bin/vault.py schedule "孫燕姿演唱會" "啟德體育園" "03/15" "2026-03-15T19:30:00+08:00"
```

## 歷史教訓
- 2026-03-08: 發生過多次因環境變數消失導致 API 呼叫失敗，已修正為檔案讀取模式。
- 2026-03-08: 統一了標題日期與事件日期的一致性，避免混淆。
