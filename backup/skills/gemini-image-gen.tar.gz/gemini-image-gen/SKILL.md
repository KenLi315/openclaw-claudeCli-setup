---
name: gemini-image-gen
description: Generate and edit images with Gemini using GOOGLE_API_KEY.
---

# Gemini Image Gen

Supports text-to-image and image-to-image.

## Run

node {baseDir}/scripts/generate_image.mjs --prompt "..." --filename "~/.openclaw/media/images/out.png"

Optional: --input-image "path" for image-to-image, --aspect-ratio 1:1
