---
name: memory-vault-manager
description: 自動化管理 Ken 的 GitHub 記憶庫與 Trello 任務儀表板。
metadata: {"clawdbot":{"emoji":"🧠","requires":{"bins":["python3"],"env":["TRELLO_API_KEY","TRELLO_TOKEN"]}}}
---

# Memory Vault Manager Skill

將會話總結、任務及知識提取自動化，並同步至 Trello 與 GitHub。

## 核心規則 (Updated 2026-03-08)

1.  **憑證永久化**：憑證必須存放在 `~/.openclaw/credentials/trello.json`，嚴禁僅依賴臨時環境變數。
2.  **標題自動日期規範 (NEW)**：
    -   腳本會自動根據當前日期（或指定的 `event_date`）在卡片標題前加上 `[MM/DD]`。
    -   **嚴禁**在 `Title` 參數中手動輸入日期前綴，否則會出現 `[03/08] [03/08]` 的重複現象。
3.  **內容換行規範 (NEW)**：
    -   Trello 描述內容必須採用「真正格行」的風格。
    -   在 shell 中傳遞參數時，請確保換行符號被正確解釋（使用 actual newlines）。
4.  **日程命名規範**：
    -   日程類型的卡片，標題必須使用「事件發生日期」作為前綴，且應優先使用 Trello 的原生參數 (`start`, `due`)。
5.  **分類邏輯**：
    -   `summary`: 歸類至「會話總結 (Session Summaries)」欄位。
    -   `task`: 歸類至「任務 (Tasks)」欄位。
    -   `schedule`: 歸類至「日程 (Schedule)」欄位。

## 指令範例

### 1. 提交會話總結 (Session Summary)
```bash
# 注意：標題不要寫日期！
python3 ~/.openclaw/skills/memory-vault-manager/bin/vault.py summary "技能體系強化與備份完成" "內容描述...（支持真正換行）"
```

### 2. 記錄正式日程 (New Schedule)
```bash
# 參數：模式 "標題" "內容" "事件日期(MM/DD)" "ISO開始時間"
python3 ~/.openclaw/skills/memory-vault-manager/bin/vault.py schedule "孫燕姿演唱會" "啟德體育園" "03/15" "2026-03-15T19:30:00+08:00"
```

## 歷史教訓
- 2026-03-08: 出現過標題重複日期 `[03/08] [03/08]`，已更新規則：AI 不得手動加日期。
- 2026-03-08: 出現過 `\n` 字元未轉義，已更新規則：必須採用實際換行風格。
