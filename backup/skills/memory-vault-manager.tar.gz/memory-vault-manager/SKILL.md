---
name: memory-vault-manager
description: 自動化管理 Ken 的 GitHub 記憶庫與 Trello 任務儀表板。
metadata: {"clawdbot":{"emoji":"🧠","requires":{"bins":["python3"],"env":["TRELLO_API_KEY","TRELLO_TOKEN"]}}}
---

# Memory Vault Manager Skill

將會話總結、任務及知識提取自動化，並同步至 Trello 與 GitHub。

## 指令範例

### 1. 提交會話總結 (Session Summary)
```bash
python3 ~/.openclaw/skills/memory-vault-manager/bin/vault.py summary "標題" "內容描述"
```
*   自動在 Trello 「會話總結」欄位建立卡片（標註當前時間）。
*   自動更新本地 `memory/YYYY-MM-DD.md` 並同步 GitHub。

### 2. 分派新任務 (New Task)
```bash
python3 ~/.openclaw/skills/memory-vault-manager/bin/vault.py task "任務標題" "任務內容描述"
```
*   自動在 Trello 「任務」欄位建立卡片。

## 核心規則
- 標題自動加入 `[MM/DD]` 前綴。
- 描述開頭自動加入 `**建立時間：YYYY-MM-DD HH:MM:SS**`。
- 本地 Markdown 檔案一律採 APPEND 模式，不覆蓋舊內容。
