#!/bin/bash
set -euo pipefail
RESULT_DIR="${CLAUDE_CODE_RESULT_DIR:-/tmp/claude-code-results}"
OUTPUT_FILE="${CLAUDE_CODE_OUTPUT_FILE:-/tmp/claude-coding-output.txt}"
TASK_OUTPUT="${RESULT_DIR}/task-output.txt"
META_FILE="${RESULT_DIR}/task-meta.json"
PROMPT="${1:-}"
TASK_NAME="${2:-claude-task-$(date +%s)}"
[ -z "$PROMPT" ] && echo "Usage: dispatch-claude-code.sh \"prompt\" [task_name]" >&2 && exit 1
mkdir -p "$RESULT_DIR"
printf '{"task_name":"%s","status":"running"}\n' "$(echo "$TASK_NAME" | sed 's/"/\\"/g')" > "$META_FILE"
> "$OUTPUT_FILE"
> "$TASK_OUTPUT"
export PROMPT
if command -v script >/dev/null 2>&1; then
    script -q -c 'claude -p "$PROMPT" --verbose' "$OUTPUT_FILE" 2>&1 | tee "$TASK_OUTPUT"
else
    claude -p "$PROMPT" --verbose 2>&1 | tee "$OUTPUT_FILE" | tee "$TASK_OUTPUT"
fi
EXIT_CODE=${PIPESTATUS[0]}
printf '{"task_name":"%s","status":"done","exit_code":%d}\n' "$(echo "$TASK_NAME" | sed 's/"/\\"/g')" "$EXIT_CODE" > "$META_FILE"
exit $EXIT_CODE
