---
name: claude-cli-coding
description: Delegate coding tasks to Claude Code CLI. Zero-polling via dispatch script + Hooks.
user-invocable: true
metadata:
  {"openclaw":{"requires":{"env":["ANTHROPIC_BASE_URL"]}}}
---

# Claude CLI Coding Skill（零輪詢）

## Workflow

1. Tell user: "已分派給 Claude CLI 執行，完成後會主動通知您。"
2. Run: nohup /app/claude-cli-coding-skill/scripts/dispatch-claude-code.sh '任務描述' > /dev/null 2>&1 &
3. Return immediately. When notified, read /tmp/claude-code-results/latest.json and report.
