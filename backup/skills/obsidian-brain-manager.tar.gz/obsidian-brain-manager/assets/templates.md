# PERSON Template
- **Name**: 
- **Role/Company**: 
- **Last Interaction**: {{date}}
- **Key Traits**: 
- **Notes**: 

# IDEA Template
- **Title**: 
- **Context**: 
- **Proposed Solution**: 
- **Status**: Draft

# PROJECT Template
- **Project Name**: 
- **Objective**: 
- **Stakeholders**: 
- **Timeline**: 
- **Status**: Active
