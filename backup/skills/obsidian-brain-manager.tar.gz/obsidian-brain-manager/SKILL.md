---
name: obsidian-brain-manager
description: Manage Ken's Obsidian vault as the ultimate long-term memory system. Use for (1) Compulsory pre-dialogue retrieval, (2) Auto-linking people/ideas/logs after conversations, (3) Periodic vault maintenance and backlink optimization, (4) Strict data routing (Ideas/Logs to Obsidian, Actions to Trello).
---

# Obsidian Brain Manager (Supreme Directive V2)

This skill is the "Supreme Directive" for memory management. It transforms all conversations into structured, interlinked knowledge nodes.

## Core Directives

### 1. The Pre-Search Rule (Retrieval-First)
**BEFORE** processing any request mentioning people, projects, or historical data:
- **Search**: Grep the `memory/` directory in `KenLi315/ken-obsidian-vault`.
- **Reference**: Use the found data as the basis for your response. 
- **Constraint**: Never guess if a record exists. Search first.

### 2. The Auto-Link Rule (Conversation Checkout)
**WHEN** a conversation ends or Ken says "Save/Store":
- **Analyze**: Identify all Persons, Ideas, and Events mentioned.
- **Action**: Create or Update their respective Markdown files.
- **Linking**: Use `[[Double Brackets]]` to create bi-directional links between the current Log and the referenced nodes.
- **Validation**: Ensure accuracy. Do not create records for hypothetical examples.

### 3. The Maintenance Rule (Refactoring)
**PERIODICALLY**:
- **Audit**: Scan the entire vault for missing links.
- **Enrich**: Update "Orphan" notes with tags or links to broader concepts.
- **Optimize**: Improve metadata in `USER.md` based on new preferences.

### 4. The Routing Rule (Strict Separation)
- **Obsidian**: Ideas, Summaries, People, Knowledge. (GitHub Sync)
- **Trello**: Deadlines, Checklists, Status tracking. (API Sync)
- **Rule**: Never put a "Session Summary" in Trello unless it's an actionable task.

## Execution Pattern
1. Read `AGENTS.md` to confirm the directive.
2. Use `vault.py` for syncing to `KenLi315/ken-obsidian-vault`.
3. Perform a `git pull` equivalent (via GitHub API check) to stay updated.
