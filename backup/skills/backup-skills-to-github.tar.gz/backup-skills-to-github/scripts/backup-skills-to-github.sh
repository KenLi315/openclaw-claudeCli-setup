#!/bin/bash
set -e
REPO="${GITHUB_BACKUP_REPO:-}"
TOKEN="${GITHUB_TOKEN:-}"
SKILLS_ROOT="${OPENCLAW_STATE_DIR:-$HOME/.openclaw}/skills"
TMP="/tmp/skills-backup"
if [ -z "$TOKEN" ] || [ -z "$REPO" ]; then
  echo "[backup-skills] GITHUB_TOKEN 或 GITHUB_BACKUP_REPO 未設定"
  exit 1
fi
[ -d "$SKILLS_ROOT" ] || { echo "[backup-skills] 找不到 skills 目錄"; exit 1; }
mkdir -p "$TMP"
GITHUB_SKILLS=""
RESP=$(curl -s -H "Authorization: token $TOKEN" "https://api.github.com/repos/$REPO/contents/backup/skills" 2>/dev/null) || true
if echo "$RESP" | grep -q '"name"' && ! echo "$RESP" | grep -q '"message"'; then
  GITHUB_SKILLS=$(echo "$RESP" | grep -oE '"[a-zA-Z0-9_-]+\.tar\.gz"' | tr -d '"' | sed 's/\.tar\.gz$//' | tr '\n' ' ')
fi
BACKED_UP=""
NEW_SKILLS=""
for skill_dir in "$SKILLS_ROOT"/*/; do
  [ -d "$skill_dir" ] || continue
  skill_name=$(basename "$skill_dir")
  [ -f "$skill_dir/SKILL.md" ] || continue
  tar -czf "$TMP/$skill_name.tar.gz" -C "$SKILLS_ROOT" "$skill_name"
  B64=$(base64 -w0 "$TMP/$skill_name.tar.gz" 2>/dev/null || base64 -i "$TMP/$skill_name.tar.gz" 2>/dev/null)
  curl -s -X PUT -H "Authorization: token $TOKEN" -H "Accept: application/vnd.github.v3+json" \
    -d "{\"message\":\"Backup skill $skill_name\",\"content\":\"$B64\"}" \
    "https://api.github.com/repos/$REPO/contents/backup/skills/$skill_name.tar.gz" >/dev/null 2>&1
  BACKED_UP="${BACKED_UP}${skill_name},"
  echo " $GITHUB_SKILLS " | grep -q " $skill_name " || NEW_SKILLS="${NEW_SKILLS}${skill_name},"
done
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
FULL_FILE="skills-backup-$TIMESTAMP.tar.gz"
tar -czf "$TMP/$FULL_FILE" -C "$(dirname "$SKILLS_ROOT")" "$(basename "$SKILLS_ROOT")"
B64=$(base64 -w0 "$TMP/$FULL_FILE" 2>/dev/null || base64 -i "$TMP/$FULL_FILE" 2>/dev/null)
curl -s -X PUT -H "Authorization: token $TOKEN" -H "Accept: application/vnd.github.v3+json" \
  -d "{\"message\":\"Full skills backup $TIMESTAMP\",\"content\":\"$B64\"}" \
  "https://api.github.com/repos/$REPO/contents/backup/$FULL_FILE" >/dev/null 2>&1
BACKED_UP=$(echo "$BACKED_UP" | sed 's/,$//')
NEW_SKILLS=$(echo "$NEW_SKILLS" | sed 's/,$//')
echo "[backup-skills] 完成"
echo "BACKED_UP=$BACKED_UP"
echo "NEW_SKILLS=$NEW_SKILLS"
echo "FULL_BACKUP=backup/$FULL_FILE"
rm -rf "$TMP"
