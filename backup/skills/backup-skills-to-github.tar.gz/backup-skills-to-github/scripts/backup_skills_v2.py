import os
import tarfile
import base64
import json
import subprocess
from datetime import datetime

# Enforce Environment Variables
token = os.environ.get("GITHUB_TOKEN")
repo = os.environ.get("GITHUB_BACKUP_REPO")
if not token or not repo:
    print("Error: GITHUB_TOKEN or GITHUB_BACKUP_REPO not set.")
    exit(1)

# Enforce Single Source of Truth
skills_root = os.path.expanduser("~/.openclaw/skills")
tmp_dir = "/tmp/openclaw-backup-v2"
os.makedirs(tmp_dir, exist_ok=True)

def upload_to_github(path, content_b64, message):
    url = f"https://api.github.com/repos/{repo}/contents/{path}"
    # Check for existing file SHA to allow updates
    get_cmd = ["curl", "-s", "-H", f"Authorization: token {token}", url]
    res = subprocess.run(get_cmd, capture_output=True, text=True)
    sha = None
    if res.returncode == 0:
        try:
            data = json.loads(res.stdout)
            if "sha" in data:
                sha = data["sha"]
        except:
            pass
    
    payload = {"message": message, "content": content_b64}
    if sha:
        payload["sha"] = sha
        
    payload_file = os.path.join(tmp_dir, "payload.json")
    with open(payload_file, "w") as f:
        json.dump(payload, f)
        
    put_cmd = [
        "curl", "-s", "-X", "PUT",
        "-H", f"Authorization: token {token}",
        "-H", "Accept: application/vnd.github.v3+json",
        "-d", f"@{payload_file}",
        url
    ]
    result = subprocess.run(put_cmd, capture_output=True, text=True)
    return result.returncode == 0

# 1. Individual Skills Backup
backed_up = []
if os.path.exists(skills_root):
    for skill_name in os.listdir(skills_root):
        skill_path = os.path.join(skills_root, skill_name)
        if not os.path.isdir(skill_path) or not os.path.exists(os.path.join(skill_path, "SKILL.md")):
            continue
            
        tar_path = os.path.join(tmp_dir, f"{skill_name}.tar.gz")
        with tarfile.open(tar_path, "w:gz") as tar:
            tar.add(skill_path, arcname=skill_name)
            
        with open(tar_path, "rb") as f:
            b64 = base64.b64encode(f.read()).decode("utf-8")
            
        if upload_to_github(f"backup/skills/{skill_name}.tar.gz", b64, f"Verified backup for skill: {skill_name}"):
            backed_up.append(skill_name)

# 2. Strict Naming Full Backup
timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
full_file = f"skills-backup-{timestamp}.tar.gz"
full_tar_path = os.path.join(tmp_dir, full_file)

with tarfile.open(full_tar_path, "w:gz") as tar:
    # Standard internal structure: skills/
    tar.add(skills_root, arcname="skills")

with open(full_tar_path, "rb") as f:
    b64 = base64.b64encode(f.read()).decode("utf-8")

if upload_to_github(f"backup/{full_file}", b64, f"Full verified skills backup {timestamp}"):
    print(f"STATUS=SUCCESS")
    print(f"BACKED_UP={','.join(backed_up)}")
    print(f"FULL_BACKUP={full_file}")
else:
    print("STATUS=FAILED")
