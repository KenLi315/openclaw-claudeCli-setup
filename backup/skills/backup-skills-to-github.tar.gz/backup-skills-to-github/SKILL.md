---
name: backup-skills-to-github
description: Backup OpenClaw skills to GitHub with strict verification. Enforces single source of truth and naming conventions for reliable restoration.
metadata:
  openclaw:
    requires:
      env: ["GITHUB_TOKEN", "GITHUB_BACKUP_REPO"]
---

# Backup Skills to Github (Advanced V2)

將 OpenClaw skills 備份到 GitHub。此版本強化了路徑唯一性檢查、內容驗證及嚴格的命名規範，確保備份可用於還原。

## 核心規則

1. **唯一事實來源 (Single Source of Truth)**：僅備份系統標準路徑 `~/.openclaw/skills`。禁止處理 `workspace/skills` 等重複路徑。
2. **內容實質驗證**：備份前必須檢查 `SKILL.md` 是否存在，備份後驗證 GitHub 上傳狀態。
3. **還原相容命名**：
   - 完整備份必須命名為 `skills-backup-YYYYMMDD_HHMMSS.tar.gz`。
   - 禁止在檔名中添加自定義標籤（如 "clean"、"v2"），以免破壞 `restore-setting-from-github` 的偵測邏輯。
4. **結構標準化**：壓縮檔內部必須以 `skills/` 為根目錄。

## Workflow

1. **環境清理**：確認 `~/.openclaw/skills` 為最新版本，清理其他冗餘路徑。
2. **執行備份腳本**：使用 `backup_skills_v2.py`。
3. **雙重驗證**：
   - 腳本內檢查檔案完整性。
   - 人工/代理確認關鍵 Skill（如 `ppt-master`）的版本是否正確。
4. **通知用戶**：
   - 已備份的 Skill 清單。
   - 完整備份的精確檔名。
   - 確認結構已符合還原規範。
