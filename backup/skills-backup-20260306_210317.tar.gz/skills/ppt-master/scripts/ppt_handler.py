import sys
import json
from pptx import Presentation
from pptx.util import Inches
import os

def delete_slide(prs, slide):
    id_list = [s.slide_id for s in prs.slides]
    slide_id = slide.slide_id
    slide_index = id_list.index(slide_id)
    xml_slides = prs.slides._sldIdLst
    prs.slides._sldIdLst.remove(xml_slides[slide_index])

def create_ppt_from_template(data, template_path, output_path):
    if os.path.exists(template_path):
        prs = Presentation(template_path)
        while len(prs.slides) > 0:
            delete_slide(prs, prs.slides[0])
    else:
        prs = Presentation()
        prs.slide_width = Inches(13.333)
        prs.slide_height = Inches(7.5)

    for slide_data in data.get("slides", []):
        layout_index = slide_data.get("layout_index", 1)
        if layout_index >= len(prs.slide_layouts):
            layout_index = 1
        
        slide_layout = prs.slide_layouts[layout_index]
        slide = prs.slides.add_slide(slide_layout)
        
        if "title" in slide_data and slide.shapes.title:
            slide.shapes.title.text = slide_data["title"]
        
        body_content = slide_data.get("content", "")
        if body_content:
            for shape in slide.placeholders:
                if shape.placeholder_format.type in [2, 7]: # BODY or OBJECT
                    shape.text = body_content
                    break
            
        if "subtitle" in slide_data and layout_index == 0:
            for shape in slide.placeholders:
                 if shape.placeholder_format.type == 4: # SUBTITLE
                     shape.text = slide_data["subtitle"]
                     break

        if "image_path" in slide_data and os.path.exists(slide_data["image_path"]):
            from PIL import Image
            with Image.open(slide_data["image_path"]) as img:
                img_w, img_h = img.size
                ratio = img_w / img_h
            
            # Position logic: Always Bottom Right for Title and Content slides to avoid text
            max_width = Inches(4.5)
            max_height = Inches(3.0)
            
            target_width = max_width
            target_height = target_width / ratio
            
            if target_height > max_height:
                target_height = max_height
                target_width = target_height * ratio
                
            left = prs.slide_width - target_width - Inches(0.5)
            top = prs.slide_height - target_height - Inches(0.5)
            
            slide.shapes.add_picture(slide_data["image_path"], left, top, width=target_width, height=target_height)

    prs.save(output_path)
    return output_path

if __name__ == "__main__":
    action = sys.argv[1]
    if action == "create":
        data = json.loads(sys.argv[2])
        out = sys.argv[3]
        template = "skills/ppt-master/assets/template.pptx"
        create_ppt_from_template(data, template, out)
