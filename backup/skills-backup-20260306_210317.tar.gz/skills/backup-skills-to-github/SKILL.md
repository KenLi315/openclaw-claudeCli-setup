---
name: backup-skills-to-github
description: Backup OpenClaw skills to GitHub. Use when user says "backup skills to github", "備份 skills", or "sync skills to github". Compares local with GitHub, uploads new or updated skills. Requires GITHUB_TOKEN and GITHUB_BACKUP_REPO.
metadata:
  openclaw:
    requires:
      env: ["GITHUB_TOKEN", "GITHUB_BACKUP_REPO"]
---

# Backup Skills to Github

將 OpenClaw skills 備份到 GitHub。比對本地與 GitHub，上傳新 skill 或更新既有 skill。

## When to Use

用戶說「backup skills to github」「備份 skills」「sync skills to github」時使用。

## Workflow

1. 執行 bash {baseDir}/scripts/backup-skills-to-github.sh
2. 從輸出擷取 BACKED_UP、NEW_SKILLS、FULL_BACKUP
3. 通知用戶：已備份清單、新上傳的 skill、備份位置
