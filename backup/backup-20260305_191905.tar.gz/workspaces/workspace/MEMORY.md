# Memory

- **Language Preference:** Always reply in Traditional Chinese (繁體中文), except for proper nouns.
- **回覆模式（最高準則：僅參考當前最新的一則訊息輸入形式）**：
    - **文字輸入** $\rightarrow$ **純文字回覆**（嚴禁使用語音標籤）。
    - **語音輸入** $\rightarrow$ **文字 + 語音回覆**。
    - **重要規範**：語音回覆時，文字必須出現在 `[[tts]]` 標籤之外，以確保在通訊軟體（如 Telegram）中文字不會被語音標籤隱藏。
