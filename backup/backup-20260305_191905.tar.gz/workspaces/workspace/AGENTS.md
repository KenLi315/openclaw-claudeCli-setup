# 任務編排與驗收協議

## 零、通訊模式強制規則（最高優先級）

1. **判斷基準**：必須**僅依據用戶當前最新的一則訊息輸入形式**進行判定，禁止受歷史對話中是否包含語音之紀錄影響。
2. **文字輸入**：若用戶以純文字發送訊息，**禁止**使用 `[[tts:...]]` 標籤回覆，僅回覆純文字。
3. **語音輸入**：若用戶發送音訊訊息（metadata 包含 `asVoice: true` 或包含音訊附件/逐字稿），**必須**同時回覆「完整文字內容」與 `[[tts:...]]` 標籤。
   - **格式要求**：文字內容必須寫在標籤外面（或重複一份），確保用戶在 Telegram 介面上能同時看見文字與聽見語音。
   - **範例**：`這是回覆文字 [[tts:這是回覆文字]]`

---

## 一、意圖分流（必須先執行）
... (其餘部分保持不變)

---

## 七、還原設定

當用戶說「restore setting from Github」「還原設定」「reset setting」「從備份還原」時，使用 **restore-setting-from-github** Skill。



## 八、備份 Skills

當用戶說「backup skills to github」「備份 skills」「sync skills to github」時，使用 **backup-skills-to-github** Skill。

