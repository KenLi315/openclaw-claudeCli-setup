# Zeabur Setup (No Copy-Paste)

## 1) Upload files in Zeabur

Upload this whole folder to:

`/home/node/.openclaw/skills/gemini-image-gen/`

Final structure on Zeabur should be:

- `/home/node/.openclaw/skills/gemini-image-gen/SKILL.md`
- `/home/node/.openclaw/skills/gemini-image-gen/scripts/generate_image.mjs`

## 2) Set environment variable

In Zeabur -> OpenClaw service -> Variables, add:

`GOOGLE_API_KEY=<your key>`

Then restart service.

## 3) Run tests in Zeabur Command

Text to image:

```bash
node /home/node/.openclaw/skills/gemini-image-gen/scripts/generate_image.mjs --prompt "a minimalist lobster logo, flat vector, transparent background" --filename "/home/node/.openclaw/workspace/images/lobster.png" --aspect-ratio "1:1"
```

Image to image (modify):

```bash
node /home/node/.openclaw/skills/gemini-image-gen/scripts/generate_image.mjs --prompt "convert to watercolor style, keep composition and object shape" --input-image "/home/node/.openclaw/workspace/input/source.jpg" --filename "/home/node/.openclaw/workspace/images/source-watercolor.png"
```

## 4) Output location

Generated images are under:

`/home/node/.openclaw/workspace/images/`
